@component('mail::message')
# Welcome to BOOK SHARING

We are the place to connect everyone which is loving book to sharing together

All the best,

Luan Huynh
@endcomponent
