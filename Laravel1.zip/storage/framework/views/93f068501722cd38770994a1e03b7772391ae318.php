<?php $__env->startComponent('mail::message'); ?>
# Welcome to BOOK SHARING

We are the place to connect everyone which is loving book to sharing together

All the best,

Luan Huynh
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\Laravel1\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>