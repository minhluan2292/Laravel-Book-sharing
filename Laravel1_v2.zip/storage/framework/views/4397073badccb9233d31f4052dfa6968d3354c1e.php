

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

            <form method="POST" action="/addfrompage">
                        <?php echo csrf_field(); ?>
                        <div style="display:flex;">
                            From:  <input style="width:10%;margin-left:10px;" id="page" type="page" class="mr-3 form-control <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="page" value="<?php echo e(old('page')); ?>" required autocomplete="page" autofocus>
                                    <?php $__errorArgs = ['page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            To:  <input style="width:10%;margin-left:10px;" id="topage" type="topage" class="form-control <?php $__errorArgs = ['topage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="topage" value="<?php echo e(old('topage')); ?>" required autocomplete="topage" autofocus>
                                    <?php $__errorArgs = ['topage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="btn btn-primary ml-2"> ADD </button>
                        </div>

            </form>
            <?php if(isset($add)): ?>
                Add <?php echo e($add); ?>  
                Dup <?php echo e($dup); ?> 
                Error <?php echo e($error); ?> 
            <?php endif; ?>
            <account-management id="account-management" data-app></account-management>

    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel1\resources\views/chotot/bds.blade.php ENDPATH**/ ?>