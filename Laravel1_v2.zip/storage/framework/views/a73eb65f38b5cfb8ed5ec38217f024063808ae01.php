<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3 p-5">
            <img style="max-height: 170px;" src="https://upload.wikimedia.org/wikipedia/commons/d/df/Books-on-Table-Circle-SGBerlin.png" alt="">
        </div>
        <div class="col-9 pt-5">
        <div>
        <div class="d-flex justify-content-between align-items-baseline">
            <h1><?php echo e($user->username); ?></h1>
            <a href="#">Add new post</a>
        </div>
            <div class="d-flex">
                <div class="pr-5"><strong>1234</strong> posts</div>
                <div class="pr-5"><strong>99.9k</strong> followers</div>
                <div class="pr-5"><strong>999</strong> following</div>
            </div>
            <div class="pt-4 font-weight-bold"><?php echo e($user->profile->title ?? 'N/A'); ?></div>
            <div><?php echo e($user->profile->description ?? 'N/A'); ?></div>
            <div><a href="#"><?php echo e($user->profile->url ?? 'N/A'); ?></a></div>
        </div>
    </div>

    <div class="row pt-5">
            <div class="col-4"><img src="https://instagram.fsgn5-6.fna.fbcdn.net/v/t51.2885-15/e35/c180.0.1080.1080a/s480x480/90704351_208376760499662_4082408571451767152_n.jpg?_nc_ht=instagram.fsgn5-6.fna.fbcdn.net&_nc_cat=106&_nc_ohc=ZvV88PYS17QAX_5BI0J&oh=1f3227a13143c084b2813a642e364636&oe=5EEC4E4D" class="w-100"></div>
            <div class="col-4"><img src="https://instagram.fsgn5-6.fna.fbcdn.net/v/t51.2885-15/e35/c180.0.1080.1080a/s480x480/90704351_208376760499662_4082408571451767152_n.jpg?_nc_ht=instagram.fsgn5-6.fna.fbcdn.net&_nc_cat=106&_nc_ohc=ZvV88PYS17QAX_5BI0J&oh=1f3227a13143c084b2813a642e364636&oe=5EEC4E4D" class="w-100"></div>
            <div class="col-4"><img src="https://instagram.fsgn5-6.fna.fbcdn.net/v/t51.2885-15/e35/c180.0.1080.1080a/s480x480/90704351_208376760499662_4082408571451767152_n.jpg?_nc_ht=instagram.fsgn5-6.fna.fbcdn.net&_nc_cat=106&_nc_ohc=ZvV88PYS17QAX_5BI0J&oh=1f3227a13143c084b2813a642e364636&oe=5EEC4E4D" class="w-100"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel1\resources\views/home.blade.php ENDPATH**/ ?>